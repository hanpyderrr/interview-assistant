// src/service-worker.ts
var STORAGE_KEY = "pairing";
var PAIR_PROBE_DOM = "__pair_probe__";
async function postDomToDesktop(pairing, dom, fetchImpl, extras) {
  const url = `http://127.0.0.1:${pairing.port}/dom?t=${encodeURIComponent(pairing.token)}`;
  const payload = { dom };
  if (extras?.reqId) payload.reqId = extras.reqId;
  if (extras?.meta) payload.meta = extras.meta;
  if (extras?.envelope) payload.envelope = extras.envelope;
  if (extras?.probe) payload.probe = true;
  let res;
  try {
    res = await fetchImpl(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
  } catch {
    return { kind: "refused" };
  }
  switch (res.status) {
    case 200: {
      try {
        const body = await res.json();
        return body && body.success ? { kind: "success" } : { kind: "error", message: "Unexpected response body" };
      } catch {
        return { kind: "error", message: "Malformed success response" };
      }
    }
    case 400:
      return { kind: "bad-request" };
    case 401:
      return { kind: "unauthorized" };
    case 409:
      return { kind: "no-session" };
    case 413:
      return { kind: "too-large" };
    case 429:
      return { kind: "rate-limited" };
    default:
      return { kind: "http-error", status: res.status };
  }
}
function parsePairingString(raw) {
  const trimmed = (raw || "").trim();
  const idx = trimmed.indexOf(":");
  if (idx <= 0) return null;
  const portStr = trimmed.slice(0, idx).trim();
  const token = trimmed.slice(idx + 1).trim();
  const port = Number(portStr);
  if (!Number.isInteger(port) || port < 1 || port > 65535) return null;
  if (!/^[A-Za-z0-9_-]{16,}$/.test(token)) return null;
  return { port, token };
}
var PORT_BASE = 4123;
var PORT_RANGE = 12;
async function resolveLivePort(fetchImpl, hint) {
  const candidates = [];
  if (hint && hint >= PORT_BASE && hint < PORT_BASE + PORT_RANGE) candidates.push(hint);
  for (let p = PORT_BASE; p < PORT_BASE + PORT_RANGE; p++) {
    if (p !== hint) candidates.push(p);
  }
  for (const port of candidates) {
    try {
      const res = await fetchImpl(`http://127.0.0.1:${port}/healthz`, { method: "GET" });
      if (res.status === 200) {
        const body = await res.json().catch(() => null);
        if (body && body.ok === true) return port;
      }
    } catch {
    }
  }
  return null;
}
async function fetchPairToken(port, fetchImpl) {
  let res;
  try {
    res = await fetchImpl(`http://127.0.0.1:${port}/pair`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: "{}"
    });
  } catch {
    return { kind: "refused" };
  }
  if (res.status === 200) {
    try {
      const body = await res.json();
      if (body && typeof body.token === "string" && body.token.length >= 16) {
        return { kind: "paired", token: body.token };
      }
      return { kind: "error", message: "Malformed pair response" };
    } catch {
      return { kind: "error", message: "Malformed pair response" };
    }
  }
  if (res.status === 410) return { kind: "not-armed" };
  if (res.status === 403) return { kind: "forbidden" };
  return { kind: "error", message: `Unexpected pair status ${res.status}` };
}
var INTERNAL_URL_RE = /^(chrome|edge|brave|arc|about|chrome-extension|moz-extension|devtools|view-source|chrome-untrusted):/i;
function isCapturable(tab) {
  if (!tab || tab.id == null || !tab.url) return false;
  if (tab.incognito) return false;
  if (INTERNAL_URL_RE.test(tab.url)) return false;
  return true;
}
var LAST_ACTIVE_TTL_MS = 5 * 60 * 1e3;
function pickBestTab(lastActive, windows, now, ttlMs = LAST_ACTIVE_TTL_MS) {
  if (lastActive && now - lastActive.ts < ttlMs) {
    const live = windows.find((t) => t.id === lastActive.tabId);
    if (live && isCapturable(live)) return lastActive.tabId;
  }
  for (const t of windows) {
    if (isCapturable(t)) return t.id;
  }
  return null;
}
async function getPairing() {
  const stored = await chrome.storage.local.get(STORAGE_KEY);
  const p = stored[STORAGE_KEY];
  if (p && typeof p.port === "number" && typeof p.token === "string") {
    return { port: p.port, token: p.token };
  }
  return null;
}
async function setPairing(pairing) {
  await chrome.storage.local.set({ [STORAGE_KEY]: pairing });
}
async function clearPairing() {
  await chrome.storage.local.remove(STORAGE_KEY);
}
async function extractFromTab(tabId) {
  await chrome.scripting.executeScript({
    target: { tabId },
    files: ["content-script.js"]
  });
  const response = await chrome.tabs.sendMessage(tabId, { type: "natively:extract" });
  if (!response) throw new Error("No response from page");
  if (!response.ok) throw new Error(response.error || "Extraction failed");
  return response.result;
}
async function sendDom(token, hintPort, dom, extras) {
  const attempt = async (port2) => postDomToDesktop({ port: port2, token }, dom, fetch, extras);
  let port = await resolveLivePort(fetch, hintPort);
  if (port == null) return { kind: "refused" };
  if (port !== hintPort) await setPairing({ port, token });
  let outcome = await attempt(port);
  if (outcome.kind === "refused" || outcome.kind === "unauthorized") {
    const rePort = await resolveLivePort(fetch, void 0);
    if (rePort == null) return { kind: "refused" };
    if (rePort !== port) {
      await setPairing({ port: rePort, token });
      port = rePort;
    }
    outcome = await attempt(port);
  }
  if (outcome.kind === "unauthorized") {
    await clearPairing();
  }
  return outcome;
}
var LAST_ACTIVE_KEY = "lastActive";
async function readLastActive() {
  try {
    const s = await chrome.storage.session.get(LAST_ACTIVE_KEY);
    const v = s[LAST_ACTIVE_KEY];
    if (v && typeof v.tabId === "number" && typeof v.ts === "number") return v;
  } catch {
  }
  return null;
}
async function recordLastActive(tab) {
  if (!isCapturable(tab)) return;
  try {
    const rec = {
      tabId: tab.id,
      windowId: tab.windowId,
      url: tab.url,
      title: tab.title,
      ts: Date.now()
    };
    await chrome.storage.session.set({ [LAST_ACTIVE_KEY]: rec });
  } catch {
  }
}
async function resolveCaptureTab() {
  const ordered = [];
  let lastFocusedId;
  try {
    const lf = await chrome.windows.getLastFocused({ populate: true, windowTypes: ["normal"] });
    lastFocusedId = lf?.id;
    const a = lf?.tabs?.find((t) => t.active);
    if (a) ordered.push(a);
  } catch {
  }
  try {
    const wins = await chrome.windows.getAll({ populate: true, windowTypes: ["normal"] });
    for (const w of wins) {
      if (w.id === lastFocusedId) continue;
      const a = w.tabs?.find((t) => t.active);
      if (a) ordered.push(a);
    }
  } catch {
  }
  if (ordered.length === 0) {
    try {
      const tabs = await chrome.tabs.query({ active: true, windowType: "normal" });
      ordered.push(...tabs.sort((a, b) => (b.id ?? 0) - (a.id ?? 0)));
    } catch {
    }
  }
  const lastActive = await readLastActive();
  const pickedId = pickBestTab(lastActive, ordered, Date.now());
  if (pickedId == null) return void 0;
  const fromSet = ordered.find((t) => t.id === pickedId);
  if (fromSet) return fromSet;
  try {
    return await chrome.tabs.get(pickedId);
  } catch {
    return void 0;
  }
}
async function captureActiveTab(opts) {
  const pairing = await getPairing();
  if (!pairing) return { outcome: { kind: "unauthorized" } };
  let tab;
  if (typeof opts?.tabId === "number") {
    try {
      tab = await chrome.tabs.get(opts.tabId);
    } catch {
      tab = void 0;
    }
  } else {
    tab = await resolveCaptureTab();
  }
  if (!tab || tab.id == null) return { outcome: { kind: "error", message: "No active tab" } };
  if (!isCapturable(tab)) {
    return { outcome: { kind: "error", message: "Cannot capture browser/internal pages" } };
  }
  let extracted;
  try {
    extracted = await extractFromTab(tab.id);
  } catch (err) {
    return { outcome: { kind: "error", message: err instanceof Error ? err.message : String(err) } };
  }
  if (!extracted.text) return { outcome: { kind: "error", message: "Page had no readable content" } };
  const meta = {
    title: extracted.title || tab.title || "",
    url: tab.url || "",
    source: extracted.source,
    pageType: extracted.pageType,
    firstLine: extracted.firstLine
  };
  const outcome = await sendDom(pairing.token, pairing.port, extracted.text, { reqId: opts?.reqId, meta });
  return { outcome, chars: extracted.text.length };
}
async function smartExtractFromTab(tabId, opts) {
  await chrome.scripting.executeScript({ target: { tabId }, files: ["content-script.js"] });
  const response = await chrome.tabs.sendMessage(tabId, {
    type: "natively:smart-extract",
    contextId: opts.contextId,
    capturedAt: opts.capturedAt,
    mode: opts.mode,
    fullPage: opts.fullPage === true,
    classifyOnly: opts.classifyOnly === true,
    extraCategories: opts.extraCategories,
    aiApproved: opts.aiApproved === true,
    // Only send the flag when explicitly disabling coding (false); omitting it
    // keeps the content-script default of coding-enabled.
    codingEnabled: opts.codingEnabled
  });
  if (!response) throw new Error("No response from page");
  if (!response.ok) throw new Error(response.error || "Smart extraction failed");
  return response.smart;
}
async function classifyMetaWithDesktop(token, port, safeMetadata) {
  if (!safeMetadata) return null;
  const livePort = await resolveLivePort(fetch, port);
  if (livePort == null) return null;
  try {
    const res = await fetch(`http://127.0.0.1:${livePort}/classify?t=${encodeURIComponent(token)}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ meta: safeMetadata })
    });
    if (res.status !== 200) return null;
    const body = await res.json();
    if (!body || typeof body.autoPolicy !== "string") return null;
    return { autoPolicy: body.autoPolicy, category: body.category };
  } catch {
    return null;
  }
}
var AI_ELIGIBLE_POLICIES = /* @__PURE__ */ new Set(["auto", "auto_if_high_confidence", "ask"]);
async function postSmartCapture(pairing, reqId, tab, smart) {
  const meta = {
    title: tab.title || "",
    url: tab.url || "",
    source: "smart-auto",
    pageType: smart.candidate.matchedCategory
  };
  const outcome = await sendDom(pairing.token, pairing.port, smart.dom, {
    reqId,
    meta,
    envelope: smart.envelope ?? void 0
  });
  if (outcome.kind === "success") {
    return { kind: "sent", chars: smart.dom.length, category: smart.candidate.matchedCategory };
  }
  return outcome;
}
async function captureAutoContext(reqId, opts = {}) {
  const pairing = await getPairing();
  if (!pairing) return { kind: "unauthorized" };
  const tab = await resolveCaptureTab();
  if (!tab || tab.id == null || !isCapturable(tab)) {
    return { kind: "none", reason: "no capturable tab" };
  }
  const contextId = `auto-${reqId}`;
  const extraCategories = opts.extraCategories;
  let smart;
  try {
    smart = await smartExtractFromTab(tab.id, {
      contextId,
      capturedAt: Date.now(),
      mode: "auto",
      fullPage: opts.fullPage,
      extraCategories,
      codingEnabled: opts.codingEnabled
    });
  } catch (err) {
    return { kind: "none", reason: err instanceof Error ? err.message : String(err) };
  }
  if (smart.blocked) return { kind: "blocked" };
  if (smart.dom) {
    return postSmartCapture(pairing, reqId, tab, smart);
  }
  if (opts.aiClassify && smart.safeMetadata) {
    const verdict = await classifyMetaWithDesktop(pairing.token, pairing.port, smart.safeMetadata);
    if (verdict && verdict.autoPolicy !== "blocked" && AI_ELIGIBLE_POLICIES.has(verdict.autoPolicy)) {
      try {
        const approved = await smartExtractFromTab(tab.id, {
          contextId,
          capturedAt: Date.now(),
          mode: "auto",
          aiApproved: true
        });
        if (approved.blocked) return { kind: "blocked" };
        if (approved.dom) return postSmartCapture(pairing, reqId, tab, approved);
      } catch (err) {
        return { kind: "none", reason: err instanceof Error ? err.message : String(err) };
      }
    }
  }
  return { kind: "none", reason: `policy=${smart.candidate.autoPolicy}` };
}
async function pairFromString(raw) {
  const parsed = parsePairingString(raw);
  if (!parsed) return { kind: "error", message: "Invalid format \u2014 expected port:token" };
  await setPairing(parsed);
  const outcome = await sendDom(parsed.token, parsed.port, PAIR_PROBE_DOM, { probe: true });
  if (outcome.kind !== "success") await clearPairing();
  return outcome;
}
async function autoPair() {
  const port = await resolveLivePort(fetch, void 0);
  if (port == null) return { kind: "refused" };
  const result = await fetchPairToken(port, fetch);
  if (result.kind === "paired") {
    await setPairing({ port, token: result.token });
  }
  return result;
}
async function connectionStatus() {
  const pairing = await getPairing();
  if (!pairing) return { kind: "unpaired" };
  return sendDom(pairing.token, pairing.port, PAIR_PROBE_DOM, { probe: true });
}
var ws = null;
var wsConnecting = false;
var wsBackoffMs = 1e3;
var WS_BACKOFF_MAX = 15e3;
function wsSend(obj) {
  try {
    if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
  } catch (_) {
  }
}
async function handleCaptureDom(reqId, tabId) {
  wsSend({ type: "capture-ack", reqId, status: "started" });
  try {
    const report = await captureActiveTab({ reqId, tabId });
    const ok = report.outcome.kind === "success";
    const reason = !ok ? "message" in report.outcome && report.outcome.message || report.outcome.kind : void 0;
    wsSend({ type: "capture-ack", reqId, status: ok ? "done" : "error", error: reason });
  } catch (err) {
    wsSend({ type: "capture-ack", reqId, status: "error", error: err instanceof Error ? err.message : String(err) });
  }
}
async function handleRequestAutoContext(reqId, opts = {}) {
  wsSend({ type: "capture-ack", reqId, status: "started" });
  try {
    const result = await captureAutoContext(reqId, opts);
    if (result.kind === "sent") {
      wsSend({ type: "capture-ack", reqId, status: "done", category: result.category });
    } else if (result.kind === "none" || result.kind === "blocked") {
      wsSend({ type: "capture-ack", reqId, status: "none", reason: result.kind === "blocked" ? "blocked" : result.reason });
    } else {
      const reason = "message" in result && result.message || result.kind;
      wsSend({ type: "capture-ack", reqId, status: "error", error: reason });
    }
  } catch (err) {
    wsSend({ type: "capture-ack", reqId, status: "error", error: err instanceof Error ? err.message : String(err) });
  }
}
async function handleListTabs(reqId) {
  try {
    const tabs = await chrome.tabs.query({});
    const list = tabs.filter((t) => isCapturable(t)).map((t) => ({ id: t.id, title: t.title || "", url: t.url || "" }));
    wsSend({ type: "tabs", reqId, tabs: list });
  } catch (_) {
    wsSend({ type: "tabs", reqId, tabs: [] });
  }
}
async function ensureWsConnected() {
  if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) return;
  if (wsConnecting) return;
  const pairing = await getPairing();
  if (!pairing) return;
  const port = await resolveLivePort(fetch, pairing.port);
  if (port == null) return;
  wsConnecting = true;
  try {
    const sock = new WebSocket(`ws://127.0.0.1:${port}/ws?t=${encodeURIComponent(pairing.token)}`);
    ws = sock;
    sock.onopen = () => {
      wsConnecting = false;
      wsBackoffMs = 1e3;
      wsSend({ type: "hello", role: "extension", v: 1 });
    };
    sock.onmessage = (ev) => {
      let msg;
      try {
        msg = JSON.parse(typeof ev.data === "string" ? ev.data : "");
      } catch {
        return;
      }
      if (!msg || typeof msg !== "object") return;
      if (msg.type === "capture-dom" && typeof msg.reqId === "string") {
        void handleCaptureDom(msg.reqId, typeof msg.tabId === "number" ? msg.tabId : void 0);
      } else if (msg.type === "request-auto-context" && typeof msg.reqId === "string") {
        void handleRequestAutoContext(msg.reqId, {
          fullPage: msg.fullPage === true,
          aiClassify: msg.aiClassify === true,
          // Defaults true; only an explicit false from the desktop disables coding.
          codingEnabled: msg.codingEnabled !== false,
          extraCategories: Array.isArray(msg.extraCategories) ? msg.extraCategories.filter((x) => typeof x === "string") : void 0
        });
      } else if (msg.type === "list-tabs" && typeof msg.reqId === "string") {
        void handleListTabs(msg.reqId);
      }
    };
    sock.onclose = () => {
      wsConnecting = false;
      if (ws === sock) ws = null;
      setTimeout(() => {
        void ensureWsConnected();
      }, wsBackoffMs);
      wsBackoffMs = Math.min(wsBackoffMs * 2, WS_BACKOFF_MAX);
    };
    sock.onerror = () => {
      try {
        sock.close();
      } catch (_) {
      }
    };
  } catch (_) {
    wsConnecting = false;
  }
}
function wsIsOpen() {
  return !!ws && ws.readyState === WebSocket.OPEN;
}
var hasChrome = typeof globalThis !== "undefined" && typeof globalThis.chrome !== "undefined" && !!chrome?.runtime?.onMessage;
if (hasChrome) {
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    (async () => {
      switch (msg?.type) {
        case "pair": {
          const r = await pairFromString(msg.value);
          if (r.kind === "success") void ensureWsConnected();
          sendResponse(r);
          return;
        }
        case "autopair": {
          const r = await autoPair();
          if (r.kind === "paired") void ensureWsConnected();
          sendResponse(r);
          return;
        }
        case "capture":
          sendResponse(await captureActiveTab());
          return;
        case "status":
          sendResponse(await connectionStatus());
          return;
        case "ws-status":
          void ensureWsConnected();
          sendResponse({ open: wsIsOpen() });
          return;
        case "unpair":
          await clearPairing();
          sendResponse({ kind: "success" });
          return;
        default:
          return;
      }
    })();
    return true;
  });
  try {
    chrome.alarms.create("natively-ws-keepalive", { periodInMinutes: 0.5 });
  } catch (_) {
  }
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === "natively-ws-keepalive") void ensureWsConnected();
  });
  chrome.runtime.onStartup.addListener(() => {
    void ensureWsConnected();
  });
  chrome.runtime.onInstalled.addListener(() => {
    void ensureWsConnected();
  });
  chrome.tabs.onActivated.addListener(({ tabId }) => {
    void ensureWsConnected();
    chrome.tabs.get(tabId).then((t) => recordLastActive(t)).catch(() => {
    });
  });
  chrome.tabs.onUpdated.addListener((_id, info, tab) => {
    if (info.status === "complete" || info.url) {
      void ensureWsConnected();
      if (tab?.active) void recordLastActive(tab);
    }
  });
  chrome.windows.onFocusChanged.addListener((winId) => {
    if (winId !== chrome.windows.WINDOW_ID_NONE) {
      void ensureWsConnected();
      wsSend({ type: "active", ts: Date.now() });
      chrome.tabs.query({ active: true, windowId: winId }).then((tabs) => {
        if (tabs[0]) void recordLastActive(tabs[0]);
      }).catch(() => {
      });
    }
  });
  chrome.action.onClicked.addListener(() => {
    void ensureWsConnected();
  });
  void ensureWsConnected();
}
export {
  LAST_ACTIVE_TTL_MS,
  fetchPairToken,
  isCapturable,
  parsePairingString,
  pickBestTab,
  postDomToDesktop,
  resolveLivePort
};
/*! For license information please see service-worker.js.LEGAL.txt */
//# sourceMappingURL=service-worker.js.map
